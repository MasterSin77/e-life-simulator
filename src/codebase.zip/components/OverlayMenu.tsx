/**
 * OverlayMenu.tsx (GPU version, with FPS & PUPS)
 */

import React, { useEffect, useRef } from 'react';
import './OverlayMenu.css';

interface OverlayMenuProps {
  isOpen: boolean;
  toggleOpen: () => void;
  resetZoom: () => void;
  setIsOpen: (value: boolean) => void;
  fps: number;
  pups: number;
}


const OverlayMenu: React.FC<OverlayMenuProps> = ({
  isOpen,
  toggleOpen,
  resetZoom,
  setIsOpen,
  fps,
  pups,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  return (
    <div
      ref={containerRef}
      className={`overlay-container ${isOpen ? 'open' : ''}`}
      onMouseLeave={() => setIsOpen(false)}
    >
      <div className="hamburger" onClick={toggleOpen}>
        ☰
      </div>

      <div className="panel">
        <h4>e-Life Stats</h4>
        <p><strong>FPS:</strong> {fps.toFixed(1)}</p>
        <p><strong>PUPS:</strong> {pups.toLocaleString()}</p>


        <button
          onClick={resetZoom}
          style={{
            marginTop: '12px',
            padding: '6px 12px',
            border: 'none',
            background: '#555',
            color: 'white',
            cursor: 'pointer',
            borderRadius: '3px'
          }}
        >
          Reset Zoom
        </button>
      </div>
    </div>
  );
};

export default OverlayMenu;
