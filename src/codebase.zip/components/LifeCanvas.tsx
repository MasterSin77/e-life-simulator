import React, { useRef, useEffect, useState } from 'react';
import { startLifeEngine } from '../webgl/lifeEngine';

interface LifeCanvasProps {
    setFps?: (fps: number) => void;
    setPups?: (pups: number) => void;
}

export default function LifeCanvas({ setFps, setPups }: LifeCanvasProps) {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const panOffset = useRef({ x: 0, y: 0 });
    const dragDelta = useRef({ x: 0, y: 0 });
    const dragStart = useRef({ x: 0, y: 0 });
    const isDragging = useRef(false);

    const offsetRef = useRef({ x: 0, y: 0 });

    const [scale, setScale] = useState(1);

    useEffect(() => {
        const canvas = canvasRef.current!;
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        startLifeEngine(canvas); // ← ONLY pass the canvas!

        const handleMouseDown = (e: MouseEvent) => {
            isDragging.current = true;
            dragStart.current = { x: e.clientX, y: e.clientY };
            dragDelta.current = { x: 0, y: 0 };
            console.log('[DOWN] Drag start', dragStart.current);
        };

        const handleMouseMove = (e: MouseEvent) => {
            if (!isDragging.current) return;
            // ✅ Invert drag direction: moving mouse left pans camera right
            dragDelta.current = {
                x: -(e.clientX - dragStart.current.x),
                y: (e.clientY - dragStart.current.y), // keep Y consistent: drag up pans up
            };
        };

        const handleMouseUp = () => {
            if (isDragging.current) {
                panOffset.current = {
                    x: panOffset.current.x + dragDelta.current.x,
                    y: panOffset.current.y + dragDelta.current.y,
                };
                dragDelta.current = { x: 0, y: 0 };
                isDragging.current = false;
                console.log('[UP] Drag ended. panOffset now:', panOffset.current);
            }
        };

        const handleWheel = (e: WheelEvent) => {
            e.preventDefault();
            setScale((s) => Math.max(1, s + e.deltaY * -0.001));
        };

        const handleResetZoom = () => {
            setScale(1);
            panOffset.current = { x: 0, y: 0 };
            dragDelta.current = { x: 0, y: 0 };
            offsetRef.current = { x: 0, y: 0 };
        };

        window.addEventListener('mousedown', handleMouseDown);
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        window.addEventListener('wheel', handleWheel, { passive: false });
        window.addEventListener('resetZoom', handleResetZoom);

        const updateOffset = () => {
            offsetRef.current = {
                x: panOffset.current.x + dragDelta.current.x,
                y: panOffset.current.y + dragDelta.current.y,
            };
            requestAnimationFrame(updateOffset);
        };
        updateOffset();

        return () => {
            window.removeEventListener('mousedown', handleMouseDown);
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
            window.removeEventListener('wheel', handleWheel);
            window.removeEventListener('resetZoom', handleResetZoom);
        };
    }, [setFps, setPups]);

    return (
        <canvas
            ref={canvasRef}
            style={{
                display: 'block',
                width: '100%',
                height: '100%',
                transform: `scale(${scale})`,
                transformOrigin: '0 0',
            }}
        />
    );
}
