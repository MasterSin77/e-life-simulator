// ✅ Final version: correct ping-pong for state & velocity
import { makeProgram } from '../utils/webglUtils';

export async function startLifeEngine(
    canvas: HTMLCanvasElement,
    setFps?: (fps: number) => void,
    setPups?: (pups: number) => void,
    getOffset?: () => { x: number; y: number }
) {
    const gl = canvas.getContext('webgl2')!;
    if (!gl) throw new Error('WebGL2 not supported');

    // === Load all shaders ===
    const densityFS = await fetch('/shaders/computeDensity.frag').then(r => r.text());
    const blurFS = await fetch('/shaders/blurDensity.frag').then(r => r.text());
    const gravityFS = await fetch('/shaders/computeGravity.frag').then(r => r.text());
    const velocityFS = await fetch('/shaders/computeVelocity.frag').then(r => r.text());
    const advectFS = await fetch('/shaders/advectPosition.frag').then(r => r.text());
    const lifeFS = await fetch('/shaders/computeLife.frag').then(r => r.text());
    const displayFS = await fetch('/shaders/display.frag').then(r => r.text());

    // === Programs ===
    const densityProgram = makeProgram(gl, densityFS);
    const blurProgram = makeProgram(gl, blurFS);
    const gravityProgram = makeProgram(gl, gravityFS);
    const velocityProgram = makeProgram(gl, velocityFS);
    const advectProgram = makeProgram(gl, advectFS);
    const lifeProgram = makeProgram(gl, lifeFS);
    const displayProgram = makeProgram(gl, displayFS);

    // === Shared VAO ===
    const quad = new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]);
    const vao = gl.createVertexArray()!;
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, quad, gl.STATIC_DRAW);
    const posLoc = gl.getAttribLocation(densityProgram, 'a_position');
    gl.enableVertexAttribArray(posLoc);
    gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);

    // === Textures and FBOs ===
    const createTex = () => {
        const t = gl.createTexture()!;
        gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, canvas.width, canvas.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        return t;
    };

    // State (A,B) & Velocity (V,W)
    let A = createTex(), B = createTex();
    let V = createTex(), W = createTex();
    let C = createTex(), D = createTex(); // intermediate density + gravity

    let fA = gl.createFramebuffer()!, fB = gl.createFramebuffer()!;
    let fV = gl.createFramebuffer()!, fW = gl.createFramebuffer()!;
    let fC = gl.createFramebuffer()!, fD = gl.createFramebuffer()!;

    [[fA, A], [fB, B], [fV, V], [fW, W], [fC, C], [fD, D]].forEach(([f, t]) => {
        gl.bindFramebuffer(gl.FRAMEBUFFER, f);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
    });

    // === Init random state ===
    const init = new Uint8Array(canvas.width * canvas.height * 4);
    for (let i = 0; i < init.length; i += 4) {
        init[i] = Math.random() < 0.05 ? 255 : 0;
        init[i + 1] = 128; // vel X
        init[i + 2] = 128; // vel Y
        init[i + 3] = 255;
    }
    gl.bindTexture(gl.TEXTURE_2D, A);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, canvas.width, canvas.height, gl.RGBA, gl.UNSIGNED_BYTE, init);

    let last = performance.now();
    let fpsSmooth = 60;

    const pass = (program: WebGLProgram, inputs: WebGLTexture[], out: WebGLFramebuffer | null) => {
        gl.useProgram(program);
        gl.uniform2f(gl.getUniformLocation(program, 'u_resolution'), canvas.width, canvas.height);
        inputs.forEach((tex, i) => {
            gl.activeTexture(gl.TEXTURE0 + i);
            gl.bindTexture(gl.TEXTURE_2D, tex);
            const name = i === 0 ? 'u_prevState'
                : i === 1 ? 'u_forceField'
                    : i === 2 ? 'u_velocity'
                        : 'u_input';
            const loc = gl.getUniformLocation(program, name);
            if (loc) gl.uniform1i(loc, i);
        });
        if (getOffset && gl.getUniformLocation(program, 'u_offset'))
            gl.uniform2f(gl.getUniformLocation(program, 'u_offset'),
                (getOffset().x / canvas.width) % 1,
                (getOffset().y / canvas.height) % 1);
        if (gl.getUniformLocation(program, 'u_timestep'))
            gl.uniform1f(gl.getUniformLocation(program, 'u_timestep'), 0.01);

        gl.bindFramebuffer(gl.FRAMEBUFFER, out);
        gl.viewport(0, 0, canvas.width, canvas.height);
        gl.drawArrays(gl.TRIANGLES, 0, 6);
    };

    function loop() {
        const now = performance.now();
        const dt = now - last;
        last = now;
        fpsSmooth = fpsSmooth * 0.9 + (1000 / dt) * 0.1;
        setFps?.(fpsSmooth);
        setPups?.(fpsSmooth * canvas.width * canvas.height);

        pass(densityProgram, [A], fB);
        pass(blurProgram, [B], fC);
        pass(gravityProgram, [C], fD);
        pass(velocityProgram, [V, D], fW);  // read V, D → write W
        pass(advectProgram, [A, W], fB);    // read A, W → write B
        pass(lifeProgram, [B], fA);         // read B → write A
        pass(displayProgram, [A, W], null); // read A + W → screen

        [A, B] = [B, A];
        [V, W] = [W, V];
        [fA, fB] = [fB, fA];
        [fV, fW] = [fW, fV];

        requestAnimationFrame(loop);
    }

    loop();
}
