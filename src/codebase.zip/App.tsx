import React, { useState } from 'react';
import LifeCanvas from './components/LifeCanvas';
import OverlayMenu from './components/OverlayMenu';

const App: React.FC = () => {
  const [fps, setFps] = useState(0);
  const [pups, setPups] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleOpen = () => setMenuOpen(!menuOpen);

  const resetZoom = () => {
    window.dispatchEvent(new CustomEvent('resetZoom'));
  };

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      margin: 0, padding: 0, overflow: 'hidden',
      position: 'relative'
    }}>
      <LifeCanvas setFps={setFps} setPups={setPups} />
      <OverlayMenu
        isOpen={menuOpen}
        toggleOpen={toggleOpen}
        resetZoom={resetZoom}
        setIsOpen={setMenuOpen}
        fps={fps}
        pups={pups}
      />
    </div>
  );
};

export default App;
